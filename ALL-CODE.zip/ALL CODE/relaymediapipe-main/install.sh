sudo pip install picamera
sudo pip3 install aiortc
sudo pip3 install uvloop
sudo pip3 install vidgear
sudo pip3 uninstall numpy
sudo pip3 install numpy



